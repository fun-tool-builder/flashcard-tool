# Read & Repeat — Private Notes
(this file is in .gitignore — do not commit)

---

## Live site
https://dashing-trifle-f1c761.netlify.app

Nicer URL if you set it: https://readandrepeat.netlify.app

---

## Services & logins

| Service | URL | Account |
|---------|-----|---------|
| Netlify (hosting) | https://app.netlify.com | sign in with GitHub |
| GitHub (code) | https://github.com/fun-tool-builder/flashcard-tool | fun-tool-builder |
| Supabase (database + auth) | https://supabase.com/dashboard/project/zlrqzrahkrcoztockexy | your email |
| GitHub Desktop | desktop app | fun-tool-builder |
| Ko-fi (donations) | https://ko-fi.com/funprojectsbrigade | your account |

---

## Supabase credentials
(regenerate the key if ever exposed — Settings → API)

Project URL: https://zlrqzrahkrcoztockexy.supabase.co
Publishable key: sb_publishable_Cu5128PS0X33PzTCnSQVLg_K5Ec0CaM

These live at the top of index.html:
```js
const SUPABASE_URL = '...';
const SUPABASE_KEY = '...';
```

---

## Database tables (Supabase)

### user_cards
Stores each user's uploaded Excel as JSON. One row per user.
- `user_id` — links to Supabase auth
- `cards_json` — the full word list
- `filename` — shown on home screen
- `lang_code` — e.g. "he", "es", "ja" — determines RTL, font size, audio language
- `uploaded_at` — shown on home screen

### want_to_review
One row per flagged card per user.
- `user_id`
- `card_key` — english|||target (unique combo)

Both tables have Row Level Security on — users only see their own rows.

To wipe and recreate tables:
```sql
drop table user_cards;
drop table want_to_review;
```
Then re-run the create statements from the original setup.

---

## Supported languages
Hebrew, Arabic, Greek, Russian, Spanish, French, German, Italian, Portuguese, Japanese, Mandarin, Korean, Farsi, Hindi, Turkish, Ukrainian.

RTL (right-to-left): Hebrew, Arabic, Farsi
Larger font size: Japanese, Mandarin, Korean
Audio uses Web Speech API with the correct lang code per language (he-IL, es-ES, ja-JP, etc.)

---

## How to make changes

1. Edit `index.html` in the flashcard-tool folder on your Mac
2. Open GitHub Desktop
3. Write a commit message, click Commit to main
4. Click Push origin
5. Netlify redeploys automatically in ~30 seconds

---

## Repository structure

```
flashcard-tool/
├── index.html            — entire app (HTML + CSS + JS)
├── demo.xlsx             — sample word list for new users
├── README.md             — public-facing readme on GitHub
└── PRIVATE_NOTES.md      — this file (gitignored)
```

---

## Excel format the app expects

| Column | Content | Required |
|--------|---------|----------|
| A | English | Yes |
| B | Target language | Yes |
| C | Transliteration | Optional — header must contain "translit" |
| D | Category | Optional — header must contain "cat" or "group" |

- Header row is auto-detected from row 1
- Newer words go at the bottom (used for "newest first" filter)
- Language is chosen via picker modal after upload — sets RTL, font size, audio

---

## Key technical decisions & why

- **Single HTML file** — no build step, no npm, easy to edit and deploy
- **Supabase** — free tier handles auth + database, no server to manage
- **Netlify** — free hosting, auto-deploys from GitHub on every push
- **SheetJS** — parses Excel in the browser, no file upload to server needed
- **Web Speech API** — TTS built into Mac/browser, no API key needed
- **Ko-fi** — zero-fee donation button, $5 suggested, no subscription logic needed
- **Row Level Security** — each user can only access their own data, enforced at DB level

---

## If something breaks

- **Site not updating after push**: check Netlify dashboard for deploy errors
- **Login not working**: check Supabase → Authentication → Users
- **Cards not saving**: check Supabase → Table Editor → user_cards
- **Language not saving**: make sure lang_code column exists (alter table user_cards add column lang_code text default 'he')
- **Two GitHub accounts causing push issues**: use GitHub Desktop, make sure you're signed in as fun-tool-builder under GitHub Desktop → Preferences → Accounts
